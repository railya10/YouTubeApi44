package com.example.youtubeapi44.model

data class Maxres(
    val height: Int,
    val url: String,
    val width: Int
)