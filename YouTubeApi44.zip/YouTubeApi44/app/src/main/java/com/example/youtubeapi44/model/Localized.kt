package com.example.youtubeapi44.model

data class Localized(
    val description: String,
    val title: String
)