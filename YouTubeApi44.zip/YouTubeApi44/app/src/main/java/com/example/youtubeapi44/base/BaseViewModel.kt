package com.example.youtubeapi44.base

import androidx.lifecycle.ViewModel

open class BaseViewModel: ViewModel() {
}