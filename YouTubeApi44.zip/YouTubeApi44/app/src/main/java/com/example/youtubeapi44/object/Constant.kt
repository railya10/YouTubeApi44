package com.example.youtubeapi44.`object`

object Constant {

    const val channelId = "UCWOA1ZGywLbqmigxE4Qlvuw"
    const val part = "snippet,contentDetails"

}