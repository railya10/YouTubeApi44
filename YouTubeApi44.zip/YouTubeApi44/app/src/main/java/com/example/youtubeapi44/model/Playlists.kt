package com.example.youtubeapi44.model

data class Playlists (
    val kind: String? = null,
    val items: List<Item>,
)
