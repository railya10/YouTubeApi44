package com.example.youtubeapi44.model

data class PageInfo(
    val resultsPerPage: Int,
    val totalResults: Int
)