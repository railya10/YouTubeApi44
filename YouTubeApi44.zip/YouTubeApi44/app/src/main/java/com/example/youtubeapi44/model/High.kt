package com.example.youtubeapi44.model

data class High(
    val height: Int,
    val url: String,
    val width: Int
)