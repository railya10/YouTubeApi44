package com.example.youtubeapi44.ui.playlist_details

import com.example.youtubeapi44.base.BaseViewModel

class PlaylistDetailsViewModel : BaseViewModel() {
}