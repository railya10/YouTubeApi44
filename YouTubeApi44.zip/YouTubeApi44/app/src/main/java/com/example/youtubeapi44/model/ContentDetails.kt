package com.example.youtubeapi44.model

class ContentDetails(
    val itemCount: Int
)